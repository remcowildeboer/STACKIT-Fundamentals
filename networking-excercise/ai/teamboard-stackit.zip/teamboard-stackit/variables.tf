# --- Project / location ---------------------------------------------------------
variable "project_id" {
  description = "STACKIT project ID."
  type        = string
}

variable "service_account_key_path" {
  description = "Path to the STACKIT service account key (JSON)."
  type        = string
  default     = "~/.stackit/sa-key.json"
}

variable "region" {
  type    = string
  default = "eu01"
}

variable "availability_zone" {
  description = "VM and data volume must be in the same AZ."
  type        = string
  default     = "eu01-1"
}

variable "name_prefix" {
  type    = string
  default = "teamboard"
}

variable "environment" {
  type    = string
  default = "prod"
}

# --- Network --------------------------------------------------------------------
variable "network_cidr" {
  description = "Dedicated workload network. Size it for future instances + load balancer."
  type        = string
  default     = "10.20.0.0/24"
}

variable "dns_nameservers" {
  type    = list(string)
  default = ["1.1.1.1", "9.9.9.9"]
}

variable "assign_public_ip" {
  description = "Public IP for VPN/bastion access. Set false when access is fully private (e.g. via bastion in same network)."
  type        = bool
  default     = true
}

# --- Access control (least privilege) ---------------------------------------------
variable "admin_cidrs" {
  description = "Approved source ranges for SSH (corporate VPN egress / bastion range)."
  type        = list(string)

  validation {
    condition = length(var.admin_cidrs) > 0 && alltrue([
      for c in var.admin_cidrs : can(cidrhost(c, 0)) && !contains(["0.0.0.0/0", "::/0"], c)
    ])
    error_message = "admin_cidrs must contain valid CIDRs and may NOT contain 0.0.0.0/0 or ::/0 (no SSH open to the world)."
  }
}

variable "web_allowed_cidrs" {
  description = "Source ranges allowed to reach HTTP/HTTPS. Internal app: corporate range. Later replaced by the load balancer security group."
  type        = list(string)

  validation {
    condition     = alltrue([for c in var.web_allowed_cidrs : can(cidrhost(c, 0))])
    error_message = "web_allowed_cidrs must contain valid CIDRs."
  }
}

variable "web_ports" {
  type    = list(number)
  default = [80, 443]
}

# --- Compute ----------------------------------------------------------------------
variable "machine_type" {
  type    = string
  default = "g2i.2"
}

variable "image_id" {
  description = "Optional fixed image ID. Empty = latest image matching os_distro/os_version."
  type        = string
  default     = ""
}

variable "os_distro" {
  type    = string
  default = "ubuntu"
}

variable "os_version" {
  type    = string
  default = "24.04"
}

variable "boot_volume_size" {
  description = "OS disk in GB (OS only, no application data)."
  type        = number
  default     = 20
}

variable "ssh_public_key_path" {
  type    = string
  default = "~/.ssh/id_ed25519.pub"
}

variable "ssh_user" {
  description = "Default user of the chosen image (Ubuntu: ubuntu)."
  type        = string
  default     = "ubuntu"
}

# --- Data volume ------------------------------------------------------------------
variable "data_volume_size" {
  type    = number
  default = 50
}

variable "data_volume_performance_class" {
  type    = string
  default = "storage_premium_perf6"
}

variable "data_mount_point" {
  type    = string
  default = "/data"
}

# --- Operations: updates & backups ------------------------------------------------
variable "enable_backup_schedule" {
  type    = bool
  default = true
}

variable "backup_rrule" {
  type    = string
  default = "DTSTART;TZID=Europe/Amsterdam:20260101T020000 RRULE:FREQ=DAILY;INTERVAL=1"
}

variable "backup_retention_days" {
  type    = number
  default = 14
}

variable "enable_update_schedule" {
  type    = bool
  default = true
}

variable "update_rrule" {
  description = "Weekly OS patching, Sunday 03:00."
  type        = string
  default     = "DTSTART;TZID=Europe/Amsterdam:20260104T030000 RRULE:FREQ=WEEKLY;BYDAY=SU"
}

variable "update_maintenance_window" {
  description = "Maintenance window in hours (1-24)."
  type        = number
  default     = 2
}

variable "extra_labels" {
  type    = map(string)
  default = {}
}
