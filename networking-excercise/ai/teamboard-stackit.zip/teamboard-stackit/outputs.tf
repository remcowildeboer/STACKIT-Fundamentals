locals {
  access_ip = var.assign_public_ip ? stackit_public_ip.teamboard[0].ip : stackit_network_interface.teamboard.ipv4
}

output "resource_ids" {
  value = {
    project_id        = var.project_id
    network_id        = stackit_network.teamboard.network_id
    security_group_id = stackit_security_group.teamboard.security_group_id
    network_interface = stackit_network_interface.teamboard.network_interface_id
    public_ip_id      = var.assign_public_ip ? stackit_public_ip.teamboard[0].public_ip_id : null
    server_id         = stackit_server.teamboard.server_id
    data_volume_id    = stackit_volume.data.volume_id
    key_pair          = stackit_key_pair.admin.name
  }
}

output "project_id" { value = var.project_id }
output "security_group_id" { value = stackit_security_group.teamboard.security_group_id }
output "access_ip" { value = local.access_ip }
output "private_ip" { value = stackit_network_interface.teamboard.ipv4 }
output "ssh_user" { value = var.ssh_user }
output "data_mount_point" { value = var.data_mount_point }
output "data_device_path" { value = "/dev/disk/by-id/virtio-${local.data_volume_serial}" }

output "ssh_command" {
  value = "ssh ${var.ssh_user}@${local.access_ip}"
}

output "deployment_note" {
  value = <<-NOTE
    TeamBoard baseline (${var.environment}) - deployment note
    ----------------------------------------------------------
    Network        : ${stackit_network.teamboard.network_id} (${var.network_cidr})
    Security group : ${stackit_security_group.teamboard.security_group_id}
    Server         : ${stackit_server.teamboard.server_id} (${var.machine_type}, ${var.availability_zone})
    Data volume    : ${stackit_volume.data.volume_id} (${var.data_volume_size} GB, ext4, label teamboard-data)
    Mount point    : ${var.data_mount_point}  (fstab by UUID, nofail)
    Access IP      : ${local.access_ip}   private: ${stackit_network_interface.teamboard.ipv4}

    SSH (22/tcp)   : ONLY from ${join(", ", var.admin_cidrs)} - key-based, no passwords, no root login
    Web (${join(",", var.web_ports)}/tcp) : only from ${join(", ", var.web_allowed_cidrs)}
    Egress         : DNS 53, NTP 123, HTTP/HTTPS 80/443 only
    Updates        : unattended security upgrades + ${var.enable_update_schedule ? "weekly STACKIT update schedule" : "no update schedule"}
    Backups        : ${var.enable_backup_schedule ? "daily STACKIT server backup, ${var.backup_retention_days} days retention" : "not enabled"}

    Scale-out: add instances (NIC + server + own data volume) to the same network
    and security group; put a STACKIT Load Balancer in front and replace the web
    CIDR rules with a rule from the LB security group (remote_security_group_id).
  NOTE
}
