locals {
  name = "${var.name_prefix}-${var.environment}"

  labels = merge({
    app         = var.name_prefix
    environment = var.environment
    managed-by  = "terraform"
    backup      = var.enable_backup_schedule ? "daily" : "none"
  }, var.extra_labels)

  image_id = var.image_id != "" ? var.image_id : data.stackit_image_v2.os[0].id

  # Virtio exposes the first 20 chars of the volume UUID as disk serial:
  # /dev/disk/by-id/virtio-<serial>  -> stable device path inside the VM.
  data_volume_serial = substr(stackit_volume.data.volume_id, 0, 20)
}

data "stackit_image_v2" "os" {
  count      = var.image_id == "" ? 1 : 0
  project_id = var.project_id

  filter = {
    distro  = var.os_distro
    version = var.os_version
  }
}
