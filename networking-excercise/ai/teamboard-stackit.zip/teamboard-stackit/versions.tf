terraform {
  required_version = ">= 1.6.0"

  required_providers {
    stackit = {
      source  = "stackitcloud/stackit"
      version = "~> 0.86"
    }
  }

  # Production: use a remote backend with locking, e.g. STACKIT Object Storage (S3-compatible).
  # backend "s3" { ... }
}

provider "stackit" {
  default_region           = var.region
  service_account_key_path = var.service_account_key_path

  # Server backup/update schedules and the image_v2 data source are (partly) beta in the provider.
  enable_beta_resources = true
}
