# Prepared for production operations: patch window + backups (STACKIT managed services).
resource "stackit_server_update_schedule" "weekly" {
  count = var.enable_update_schedule ? 1 : 0

  project_id         = var.project_id
  server_id          = stackit_server.teamboard.server_id
  name               = "${local.name}-weekly-patching"
  rrule              = var.update_rrule
  enabled            = true
  maintenance_window = var.update_maintenance_window
}

resource "stackit_server_backup_schedule" "daily" {
  count = var.enable_backup_schedule ? 1 : 0

  project_id = var.project_id
  server_id  = stackit_server.teamboard.server_id
  name       = "${local.name}-daily-backup"
  rrule      = var.backup_rrule
  enabled    = true

  backup_properties = {
    name             = "${local.name}-backup"
    retention_period = var.backup_retention_days
    volume_ids       = null # null = all attached volumes (OS + data)
  }

  depends_on = [stackit_server_volume_attach.data]
}
