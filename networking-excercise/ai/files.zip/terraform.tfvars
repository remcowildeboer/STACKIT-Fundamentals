# ============================================================================
# TeamBoard - terraform.tfvars
# Vul de waarden tussen <...> in. Dit bestand staat in .gitignore (niet committen).
# ============================================================================

# --- STACKIT project & authenticatie -----------------------------------------
# Project-ID: STACKIT Portal > je project > Project settings (UUID)
project_id = "<jouw-project-id>"

# Service account key (JSON): Portal > Service Accounts > Service Account Keys
service_account_key_path = "~/.stackit/sa-key.json"

region            = "eu01"
availability_zone = "eu01-1"

# --- Naamgeving ------------------------------------------------------------------
name_prefix = "teamboard"
environment = "prod"

# --- Netwerk ---------------------------------------------------------------------
network_cidr     = "10.20.0.0/24"
dns_nameservers  = ["1.1.1.1", "9.9.9.9"]
assign_public_ip = true

# --- Toegang (least privilege) ---------------------------------------------------
# SSH alleen vanaf het VPN-/bastion-adres. Eigen publiek IP: curl -4 ifconfig.me
# Eén adres = /32. NOOIT 0.0.0.0/0 (Terraform weigert dat).
admin_cidrs = ["<jouw-vpn-of-publiek-ip>/32"]

# Wie de webapp mag bereiken (intern: bedrijfsrange). Voor de lab: zelfde IP.
web_allowed_cidrs = ["<jouw-vpn-of-publiek-ip>/32"]
web_ports         = [80, 443]

# --- VM ----------------------------------------------------------------------------
machine_type     = "g2i.2"
os_distro        = "ubuntu"
os_version       = "24.04"
boot_volume_size = 20
# image_id       = ""   # optioneel: vaste image-ID i.p.v. de nieuwste Ubuntu 24.04

# Public key van het keypair (zie README: ssh-keygen)
ssh_public_key_path = "~/.ssh/teamboard_ed25519.pub"
ssh_user            = "ubuntu"

# --- Datavolume ------------------------------------------------------------------
data_volume_size              = 50
data_volume_performance_class = "storage_premium_perf6"
data_mount_point              = "/data"

# --- Updates & backups -----------------------------------------------------------
enable_update_schedule    = true
update_rrule              = "DTSTART;TZID=Europe/Amsterdam:20260104T030000 RRULE:FREQ=WEEKLY;BYDAY=SU"
update_maintenance_window = 2

enable_backup_schedule = true
backup_rrule           = "DTSTART;TZID=Europe/Amsterdam:20260101T020000 RRULE:FREQ=DAILY;INTERVAL=1"
backup_retention_days  = 14

extra_labels = {
  owner = "platform-team"
}
